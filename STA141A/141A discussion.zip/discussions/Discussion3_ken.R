# Discussion 3
# Ken Wang
#
# EDA
#

# The goals of EDA
# 1) Look for patterns
# 2) Look relationships between variable
# 3) Look for errors in data
# 4) Look at the data for potential questions that we can ask

library(ggplot2)
data(mpg)

# Explore data structure
head(mpg)

nrow(mpg)
ncol(mpg)
dim(mpg)
names(mpg)
str(mpg) # Compactly display the structure of an arbitrary R object

# Explore missing data
miss.data <- apply(mpg, 2, is.na)
apply(miss.data, 2, table)

# Explore continuious variable
mean(mpg)
median(mpg)
sd(mpg)
var(mpg)
IQR(mpg)
quantitle(mpg)
fivenum(mpg)

# Graphs for continuous variable
# Boxplots
ggplot(mpg, aes(x = 1, y = displ)) +
  geom_boxplot()

# Histogram
ggplot(mpg, aes(displ)) + 
  geom_histogram(binwidth = 0.3)

# Density plot
ggplot(mpg, aes(displ)) +
  geom_density(adjust = 0.8)

# Explore categorical variable
table(mpg$manufacturer)

# Explore relationships

## Numerical vs Numerical

# Statistics
cov(mpg$cty, mpg$displ)
cov(mpg$hwy, mpg$displ)

# Graphs
# Scatter plot
ggplot(mpg, aes(displ, cty)) + 
  geom_point()

ggplot(mpg, aes(displ, hwy)) +
  geom_point()

## Numerical vs Categorical

# Graphs
# grouped box plots
ggplot(mpg, aes(drv, displ)) +
  geom_boxplot() +
  xlab("Manufacturer") +
  ylab("Engine Displacement") +
  ggtitle("Boxplots for Engine Displacement grouped by Manufacturer")

# Using facets
ggplot(mpg, aes(displ)) +
  geom_histogram(binwidth = 0.3) +
  facet_grid(class ~ drv)

ggplot(mpg, aes(displ)) +
  geom_histogram(binwidth = 0.3) +
  facet_grid(~drv)
