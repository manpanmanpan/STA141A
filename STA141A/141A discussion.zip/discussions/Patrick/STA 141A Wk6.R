#STA 141A Week 6

library(stringr)

#Data source: https://spamassassin.apache.org/old/publiccorpus/

#Let's examine these files

#We have two folders...HAM and SPAM
#HAM represents regular emails, sent by real people
#SPAM represents bad emails, sent by bots or bad faith actors
#Basically, we're going to use text mining and basic EDA to try to build a rudimetary spam classifier

#Start by going into the HAM file

#Move to the ham folder
setwd("./easy_ham")

#Let's read an example email

txt<-readLines(list.files()[2])

#It's quite obvious that this email is more complex than we could imagine
#We should probably try to get more out of it

#Let's start with something simple: getting email addresses
#I will use the str_extract function for this

emails<-str_extract(txt,"[^ ]+\\@[^ ]*?\\.[A-z]{2,3}")

#We will need to remove some of those gnarly <|>'s...
emails<-gsub("<|>|.*?:","",emails)

#Now, let's define a unique statistic from this
#How about: the number of unique emails
unique(emails)

#We need to get rid of those pesky NA's
emails<-emails[!is.na(emails)]

length(unique(emails))

#This email chain has 18 unique emails mentioned! We've just done it for one email, now let's generalize this by writing a function

num_eadd<-function(txt){
  emails<-str_extract(txt,"[^ ]+\\@[^ ]*?\\.[A-z]{2,3}")
  emails<-gsub("<|>|.*?:","",emails)
  emails<-emails[!is.na(emails)]
  n_e<-length(unique(emails))
  return(n_e)
}

#As we can see, this function only really works if we have the text already loaded into memory (this serves as a helper function)
#Generally it would be cumbersome to keep all emails in memory at once, so what we can do is write a main function that DOES load the text
#and then it runs this function.

parse_email<-function(file){
  txt<-readLines(file)
  n_e<-num_eadd(txt)
  return(n_e)
}

#Now, let's try out our new main function

num_e<-sapply(list.files(),parse_email)
#We've turned text into numbers like water into wine! Huzzah!
#Let's examine the distribution of unique addresses
hist(num_e,breaks=26)

#It seems that we have a lot at 5. It would be interesting to investigate this further

#Now, let's compare this to the spam dataset

setwd("../spam")

spam_ne<-sapply(list.files(),parse_email)

#Let's make this into a dataframe and make some comparisons

ne_df<-data.frame(n_e=c(num_e,spam_ne),type=rep(c("Ham","Spam"),times=c(length(num_e),length(spam_ne))))

#Let's see if we've found an interesting finding!

boxplot(n_e~type,ne_df)

#Perhaps so! It seems that ham tends to invoke larger comment chains. Let's dig deeper into this data.

#Let's start by looking at a spam email:

spamtxt<-readLines(list.files()[2])

head(spamtxt,100)
#Some potential leads: using the words 'you', 'spend', 'free'

#Let's look at another one

spamtxt<-readLines(list.files()[3])
head(spamtxt,100)

#Note something else important here, links to websites, especially with the words 'ad' or 'bot'

#And one more for good measure

spamtxt<-readLines(list.files()[4])
head(spamtxt,100)

#Let's test a new hypothesis: does having links in the email predict spam?
#Let's make a variable called: number of links

#Start by obtaining the number of links for this one

links<-str_extract(spamtxt,"http\\://.+")
links<-links[!is.na(links)]

#This one has 6 links in it. Let's now generalize this with a function

get_links<-function(txt){
  links<-str_extract(txt,"http\\://.+")
  links<-links[!is.na(links)]
  n_l<-length(links)
  return(n_l)
}

#Finally, let's re-integrate this into our parse email function


parse_email<-function(file){
  txt<-readLines(file)
  n_e<-num_eadd(txt)
  n_l<-get_links(txt)
  return(c(n_e,n_l))
}

#Next, let's write a function above this that obtains the data for an entire directory

parse_all_emails<-function(flist,label="Ham"){
  email_df<-data.frame(t(sapply(flist,parse_email)),label=label)
  names(email_df)[1:2]<-c("n_e","n_l")
  rownames(email_df)<-NULL
  return(email_df)
}

spam<-parse_all_emails(list.files(),"Spam")

setwd("../easy_ham")
ham<-parse_all_emails(list.files(),"Ham")

ham_and_spam<-rbind(ham,spam)

#And there we go!
boxplot(n_l~label,ham_and_spam,ylim=c(0,20))
