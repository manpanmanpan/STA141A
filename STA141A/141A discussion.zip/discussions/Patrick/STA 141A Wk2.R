#STA 141A Week 2

college<-readRDS("college_scorecard.rds")

#1. Advanced subsetting

#Special functions: !, any, all

#What if I subset by public ownership?
table(college$ownership[college$ownership=="Public"])

#What does ! do?
table(college$ownership[!college$ownership=="Public"])

#any()
any(college$grad_students==0)

#all()
all(is.na(college$minority_serving.tribal))

#2. Apply functions
#Checking the class counts
sapply(college,class)
table(sapply(college,class))

#Checking the top 5 features by most missing observations
head(sort(apply(sapply(college,is.na),2,sum),decreasing=TRUE),n=5)

#3. Quick intro to aggregate

#Motivating question: What is the average in-state tuition for colleges by ownership?
aggregate(tuition.in_state~ownership,college,mean)