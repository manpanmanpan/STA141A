#STA 141A Week 9

library(stringr) #Your homework 5 BFF

#Homework 5 Walkthrough

cities<-list.files()

sac_files<-list.files(".")

#Q4: How to parse the price
#i. We need to get the attribute price
#ii. We need to get the title price

#We can agree that the last price we'll see in this post is the attribute price
#We can ALSO agree that the first price we'll see in this post is the title price

parse_price<-function(txt){
  #INPUT: Some text.
  #OUTPUT: A title price and a attribute price
  #i. Get the attribute price
  prices<-c(att=NA,title=NA)
  txt_paste<-paste0(txt,collapse=" ")
  attprice<-unlist(str_extract_all(txt_paste,"Price: \\$[0-9,.]+"))
  if(length(attprice)>0){
    attprice<-attprice[length(attprice)] #Pick the last element
    prices$att<-gsub("Price: \\$","",attprice)#Parse the excess out. Get the cream, not the crop
  }
  #ii. Get the title price
  title<-txt[1] #First line must be the title
  tprice<-unlist(str_extract(title,"\\$[0-9,.]+"))
  if(length(tprice)>0){
    prices$title<-gsub("\\$","",tprice)
  }
  return(prices)
}

#Basically, you get two prices from each post. Then, you check if they agree with eachother.
#You could do something like: Title Price - Att Price (if both are not NA)
#And then check for very large differences

#Q5: Extract a deposit

#Let's start trying to find a deposit
#We want a SECURITY deposit, not a pet deposit

parse_deposit<-function(txt){
  #INPUT: Some textttt
  #OUTPUT: The security deposit, if it exists
  deposit<-NA
  dep<-unlist(str_extract_all(tolower(txt),"[^ ]*?[ ]*deposit[ -]*?[^ ]*?"))
  if(length(dep)>0){
    dep_amount<-str_extract(dep,"\\$[0-9,.]+")
    deposit<-gsub("\\$","",dep_amount)
  }
  return(deposit)
}

sacdep<-unlist(sapply(sac_files,function(x)parse_deposit(readLines(x))))

#Q6: Get the pets

#Basically, start with this:
#Make a regex that searches for pet phrases
pet_phrases<-"(pet|dog|cat|animal|fish|bird|hamster|parrot|horse)[es]{0,2} "

pets_yes<-"friendly|rent|deposit|max|weight|allowed|ok|welcome"
pets_no<-"no"
pets_unf<-paste0("(",c(paste("no",pet_phrases),paste(pet_phrases,"not allowed"),paste(pet_phrases,"not permitted")),")",collapse="|")

#We need to find instances where pets are being mentioned to narrow down our pet search

parse_pets<-function(txt){
  pets<-NA
  pet_search<-grep(pet_phrases,tolower(txt))
  if(length(pet_search)>0){
    pets<-txt[pet_search]
    #Let's try to detect paws-itive posts
    is_pos<-grepl(pets_yes,tolower(pets))
    #Let's try to build a basic way to detect 'no pets'
    is_neg<-grepl(pets_unf,pets)
    if(any(is_pos)&all(is_neg)==FALSE){
      pets<-"friendly"
    }
    else if(any(is_neg)){
      pets<-"unfriendly"
    }
  }
  return(pets)
}

sacpets<-unlist(sapply(sac_files,function(x)parse_pets(readLines(x))))
