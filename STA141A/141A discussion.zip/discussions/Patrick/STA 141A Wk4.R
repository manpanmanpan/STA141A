#STA 141A Wk4

#IF THE CLASS WANTS IT: Do a quick example from the college scorecard dataset.

library(ggplot2)
library(ggmap)

apt<-readRDS("cl_apartments.rds")

#Today, we will be doing exploratory data analysis and plotting on the apartments dataset

#1. Examine the relationship between square feet and price. How does the relationship change depending on major cities?

#Start by examining the data itself. Do we see any unusual values
hist(apt$sqft)
tail(sort(apt$sqft),10)
apt$sqft[apt$sqft>=10000]<-NA # It is unusual, for the context of this problem, we would like to fix the value

#Now, do the same for price
hist(apt$price)
tail(sort(apt$price),10)
apt[which(apt$price>=20000),]
apt$price[apt$price==9951095]<-995 #Need to fix these manually
apt$price[apt$price==34083742]<-3408

#Let's examine the basic scatterplot
plot(x=apt$sqft,y=apt$price) #Correlated but with outliers, data is also quite dense

#Choice of cities:
#Let's choose some cities to examine this relationship
#Conventionally, we'd like to choose cities with large amounts of data, so...
#San Francisco, San Jose, Oakland, Sacramento, Los Angeles, San Diego
big_cities<-c("San Francisco","San Jose","Oakland","Sacramento","Los Angeles","San Diego")
apt_bc<-apt[apt$city%in%big_cities,]
apt_bc$city<-factor(apt_bc$city)

#Now, let's make a plot to answer this question
#Alternative approach: density
ggplot(apt_bc,aes(x=sqft,y=price))+geom_point(alpha=.25)+xlim(c(0,2500))+facet_wrap(.~city)
ggplot(apt_bc,aes(x=sqft,y=price))+geom_density_2d(alpha=.25)+xlim(c(0,2500))+facet_wrap(.~city)

#Sacramento's apartment prices tend to increase slower as sqft goes up
#San Francisco's apartments have very quick price jumps for adding a little bit more square feet
#As square feet increases, the variation in price tends to increase, especially in S.F.
#Oakland, San Diego, San Jose, Sac have more straightforward relationship, less extreme price/size issues.
#L.A./S.F. tend to have more 'extravagant' apartment rentals.