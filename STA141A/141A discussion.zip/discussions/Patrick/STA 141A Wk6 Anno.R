
#STA 141A Week 6
#Tonight:
#1) Function writing (making modular functions)
#2) Text parsing

#I will be using data from this website tonight

#https://spamassassin.apache.org/old/publiccorpus/

#We will be extracting basic information from the entries (e-mails).
#In HW5, you may be asked to extract things that are more complex.

#So this is a pre-cursor to the text mining you may do in 141B
#We will be extracting basic statistics from the text
#If you want a more advanced treatment, look into Natural Language Processing

library(stringr)

#Going to the ham folder
setwd("./easy_ham")

#Let's say I want to read the first file
txt<-readLines(list.files()[5])

#SPAM vs. HAM: There is a flavor to what is being discussed
#HAM talks about troubleshooting linux commands
#SPAM is talking about selling life insurance

#1. Trying to write a function that extracts the email addresses from each entry
#Simple hypothesis: if there are more email addresses involved, then it is more likely to be HAM

ead<-str_extract(txt,"[A-z0-9-]+\\@[A-z0-9-]+\\.[A-z0-9-]{2,3}")

#STRATEGY FOR REGEX: Make sure you have plucked the 'low-hanging fruits'

#We could start with this regex as a baseline, and see if we can remove extra pieces

#So one strategy is to start with a more 'general' regular expression
#And then trim away the 'excess' pieces after extracting your result
ead2<-gsub("<|>","",ead)

#Regex suffers from the same difficulties as doing statistics
#If you have learned about the bias-variance trade-off
#I would definitely say that regex has some special version of that

#In plain english
#[A-z0-9-]+ 'Select one or more characters that are letters, numbers or dashes'
#\\@ 'Select a LITERAL @ symbol' Note that I use the \\ to 'escape' the '@' symbol
#\\. 'Select a LITERAL . same kind of logic as the one above
#[A-z0-9-]{2,3} 'Select this pattern but only between 2 or 3 characters'

#Getting prices
#\\$ get a literal US dollar sign, followed by
#[0-9,.]+ extract a sequence of numbers, commas and periods

#Now, let's write the function

parse_email<-function(txt){
  #INPUT: A text file
  #OUTPUT: The number of email addresses mentioned in this email
  ead<-str_extract(txt,"[A-z0-9-]+\\@[A-z0-9-]+\\.[A-z0-9-]{2,3}")
  ead_na_free<-ead[!is.na(ead)]
  num_address<-length(ead_na_free)
  return(num_address)
}

#Does it work for the test text we've been using?
parse_email(txt)

#Our principle: If this function works for one (or a special set) of cases, will it work for all of them?

#2. Writing a higher-level function
#Also called: a function that calls a function OR function-ception
#Basically, we write functions that do 'jobs'
#Sometimes, we write a function that contains other functions
#We need a function that does the following
#1. Read in the email with readLines()
#2. Parse the email addresses from the text

read_the_email<-function(file){
  #INPUT: A text file
  #OUTPUT: Relevant data extracted from the text file
  txt<-readLines(file)
  num_address<-parse_email(txt)
  return(num_address)
}

spam_num_address<-sapply(list.files(),read_the_email)

#Let's do this for the HAM data

setwd("../easy_ham")
ham_num_address<-sapply(list.files(),read_the_email)

ham_spam_df<-data.frame(n_a=c(ham_num_address,spam_num_address),
                        label=rep(c("Ham","Spam"),times=c(length(ham_num_address),
                                                          length(spam_num_address))))

boxplot(n_a~label,ham_spam_df)

#It seems that the ham has more email addresses mentioned compared to the spam
#We've officially done text mining. Now we're rad as heck.

#We're gonna get one more thing from our emails, we're going to get links
#If there are more links mentioned in the email, it is more likely to be spam

#We're going to try to extract links now
str_extract(txt,"http://[^ ]+")

get_links<-function(txt){
  #INPUT: A text file
  #OUTPUT: The number of links in the email
  links<-str_extract(txt,"http://[^ ]+")
  links_no_na<-links[!is.na(links)]
  num_links<-length(links_no_na)
  return(num_links)
}

#Now we're going to do this on all the spam files
#Before we do that, let's update our read_the_email function

read_the_email<-function(file){
  #INPUT: A text file
  #OUTPUT: Relevant data extracted from the text file
  txt<-readLines(file)
  num_address<-parse_email(txt)
  num_links<-get_links(txt)
  return(c(num_address,num_links))
}

#So let's test this
#And then, the last thing we want to do, is write our top function that will generalize
#read_the_email to an entire folder

some_spam<-t(sapply(list.files(),read_the_email))

read_all_emails<-function(file_set,label){
  #INPUT: A set of (homogenous, text) files within a directory
  #OUTPUT: A data frame with num_address, num_links, and label
  email_df<-as.data.frame(t(sapply(file_set,read_the_email)))
  names(email_df)<-c("addresses","links")
  email_df$label<-label
  rownames(email_df)<-NULL #Wipe out those nasty little row names
  return(email_df)
}

spam_df<-read_all_emails(list.files(),"Spam")

#Now, let's switch to ham
setwd("../easy_ham")
ham_df<-read_all_emails(list.files(),"Ham")

#Now, let's combine our results
spam_and_ham_df<-rbind(spam_df,ham_df)

#We have officially turned two folders full of unstructured emails into relevant data
#This is the bread and butter of data mining
#Last but not least, let's examine our results
boxplot(links~label,spam_and_ham_df)

ggplot(spam_and_ham_df,aes(x=links,y=addresses,color=label))+geom_point()