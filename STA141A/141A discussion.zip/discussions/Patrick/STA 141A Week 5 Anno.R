#STA 141A: Week 5

#I. Merge() function (and an alternative)

library(Lahman)

#So there's a table of batters and their batting history:
head(Batting)

#Let's say we have another table of the personal information of the players
head(Master)

#Objective is: use the merge function to combine these two datasets on the playerID key.

Mbatting<-merge(Master,Batting,by="playerID")

#This is very useful because now we can ask questions that use variables from both tables.
#Which state has the most games played in?
games_by_state<-aggregate(G~birthState,Mbatting,sum)

#Which state has the most games played?
head(games_by_state[order(games_by_state$G,decreasing=TRUE),])

#So we have CA, PA, NY,... makes sense that CA has the most games played
#...because CA has the most people.

#Auxiliary data: when you include data from a "separate" dataset
#Example of this: using census data when examining a housing dataset, just like in assignment 4.

census<-read.csv(list.files()[grep("DEC_",list.files())])

#1.5 Basic text parsing

#The other name is regular expressions...or regex for short
#Doing regex is a very test-heavy process

library(stringr)

#str_remove

#The reason why we are going to want to use this function
#is because there is excess text in the city names of this dataset

head(census[,3])

#We have these city names, but they have excess text we need to lop off

#str_remove(character_vector,regular_expression)

davis1<-"Davis city, California"
davis2<-"Davis CDP, California"

#We have these two strings, the objective is that after using str_remove, they should equal each other
#And both be just 'Davis'
str_remove(davis1," city, California") #That satisfies the first one, what about CDP
str_remove(davis2," CDP, California")

#How do I remove multiple strings at the same time?
#Use a | in your regex
str_remove(c(davis1,davis2)," (city|CDP), California")

#How to remove "___ County"

davis3<-"Davis CDP (Yolo County), California"
#Sometimes you may want to remove a special character in a regular expression
#You need to 'escape' the special character, using \ or \\ depending on the character
str_remove(c(davis1,davis2,davis3)," (city|CDP|CDP \\(Yolo County\\)), California")

#So this regex works for cases when it's Yolo county.
#But what about other phrases?
#e.g. Solano County, Sonoma County

#The 'select any letters' regex
#All letters [A-z]
#all lowercase [a-z]
#ALL UPPERCASE [A-Z]
#The + operator stands for 'search for this character an indefinite amount'

census[,3]<-str_remove(census[,3]," (city|CDP|town|CDP \\([A-z]+ County\\)), California")

#For assignment 4: just removing the city/CDP then California should be MORE than enough

#I do regex more than I do hypothesis testing.

#Now, we're going to get back to merging the baseball dataset to the census dataset
#We're gonna ask one question. Which cities in California have the most baseball players per capita?

#And with this, I will be using the join function from the plyr package
library(plyr)

#So our baseball data will be the 'Master' table. We need to count the entries by each player, not each season.
#Subset to CA players
MasterCA<-subset(Master,birthState=="CA")

#We're going to make a sub-dataset of the census data for merging purposes
citypop<-census[-1,3:4]
names(citypop)<-c("City","Pop")

#I need to do one more step with the baseball data
#Turn it into a dataframe with the city name and number of players
birth_table<-table(MasterCA$birthCity)
player_df<-data.frame(City=names(birth_table),Players=as.vector(birth_table))

#Now, we can join these two together
#Here's the tricky part. If a city in the census dataset has NO players
#We want to keep it and record the number of players as ZERO.
#I'm going to do something called a LEFT join here
#More specifically, I'm going to LEFT JOIN the citypop df on the players df
cityplayers<-join(citypop,player_df,type="left",by="City")
#Last but not least, we need to set the NA values in players to zero
cityplayers$Players[is.na(cityplayers$Players)]<-0

#How many cities in california have no players?

#Which city has the most baseball players per capita?
cityplayers$Pop<-as.numeric(as.character(cityplayers$Pop))

cityplayers$PPC<-cityplayers$Players/cityplayers$Pop

cityplayers[which.max(cityplayers$PPC),]

#So this is just an example of some of the questions you can ask when you use auxiliary data.

#II. Making a basic ggmap plot

#Time for some ggmap

library(ggmap)

coords<-c(-121.5011228,38.5762146)

sac<-get_googlemap(center=coords,zoom=12)

#Basically, we're going to look at Sacramento apartments using our data from HW3
#We're looking to see if we can determine whether the apartments are in downtown Sac
#based on the parking variable

apt<-readRDS("cl_apartments.rds")

#Subset to the sacramento apartments
sac_apt<-subset(apt,apt$city=="Sacramento")

#Going to make a plot with ggmap

sacplot<-ggmap(sac)+geom_point(data=sac_apt,aes(x=longitude,y=latitude,color=parking))

##Patrick's ramblings
#---
#Spoiler: Since each table is going to have all combinations of the player ID key,
#we will not have any issues with NA's or missing data.
#This is because these tables come from the same database.

#Conversely, when you try to merge two tables from different databases,
#you may have trouble because some of the levels in the 'joining variable' (e.g. ID)
#May exist in one database but not exist in another
#This problem is rectified by specifying HOW you want to join the tables
#I will show an alternative to merge() that helps with this problem.