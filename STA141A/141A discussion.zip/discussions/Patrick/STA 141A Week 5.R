#Part I: Merging Data

#Merge function
?merge

library(Lahman)

#Question, what's the total number of games played by state?
bat_master<-merge(Batting,Master,by="playerID")
g_bystate<-aggregate(G~birthState,bat_master,sum)
head(g_bystate[order(g_bystate$G,decreasing=TRUE),],10)

#A nice alternative: join function from plyr
library(plyr)

#(Toy with this: left join, inner join, right join)

#Quick detour: Parsing text data (Census dataset)
library(stringr)
?str_remove
census<-read.csv(list.files()[grep("DEC_10",list.files())])
#Want: city names from census
head(census[,3])

#Strategy: If data is consistent, test on one string type, should work for rest
str_remove("Davis city, California"," city, California")
#Sometimes, we may need to include additional patterns, here's a trick:
str_remove("Davis CDP, California"," (city|CDP), California")

#Now try that on the column
str_remove(census[,3]," (city|CDP), California")

#Let's add that in, and get the population values. Now we have two datasets that have an auxiliary relationship.
#Let's answer a question. Are the number of MLB players in CA proportional to

census[,3]<-str_remove(census[,3]," (city|CDP), California")

#Step I. Get city names w/ population

citypop<-census[-1,3:4]
citypop[,2]<-as.numeric(as.character(citypop[,2]))
names(citypop)[1]<-"City"

#Step II. Get city names from baseball master database
#i. Filter to CA
MasterCA<-Master[Master$birthState=="CA",]
#ii. Count the number by each city
MasterTable<-table(MasterCA$birthCity)
#iii. Make table -> df
PlayerCounts<-data.frame(City=names(MasterTable),Players=as.vector(MasterTable))

#iv. Now when merging, we want there to be NA's when the city name doesn't show up
library(plyr)
player_city<-join(citypop,PlayerCounts,type="left",by="City") #This is a LEFT join
player_city$Players[is.na(player_city$Players)]<-0

#Now we can answer the question, which city has the most baseball players per capita?
player_city$BPPC<-player_city$Players/player_city$HD01_S001
player_city[which.max(player_city$BPPC),]
#A city with 20 people pops up as the largest value. Why might this be problematic?

#Part II: ggmap

library(ggmap)

#Oh no, google is poop now!
#We need to directly look at google maps now

gmap<-get_googlemap(center=c(-121.5029979,38.581457),zoom=12)

#Let's load in the apartment data

apt<-readRDS("cl_apartments.rds")

sac_apt<-subset(apt,place=="Sacramento")

#Re-answering our question
sacto<-ggmap(gmap)+geom_point(data=sac_apt,aes(x=longitude,y=latitude,color=parking),alpha=.5)
sacto

#The points with covered off-street/no-parking are all downtown
