#STA 141A, Week 9

#HW5 walkthrough

library(stringr)

#setwd("./Desktop/Fall 18/messy")

cities<-list.files()

#4. Extract the rental price from the title of each Craigslist post.
#Do all of the titles haveprices? How do these prices compare to the user-specified prices (the price attribute)?

#Start by examining one file
sac_files<-list.files("./sacramento",full.names=TRUE)

readLines(sac_files[1])

#Note that we see there is a price attribute on the bottom
#Let's write a function called parse price

parse_price<-function(txt){
  txt_paste<-paste0(txt,collapse=" ") #I'm going to do this to avoid NA redundancy
  attprice<-unlist(str_extract_all(txt_paste,"Price\\: \\$[0-9.,]+"))
  #If multiple elements are returned, select the last element
  if(length(attprice)>0){
    attprice<-attprice[length(attprice)]
    #If we got the price, let's tidy it until we have just a number
    attprice<-gsub("Price: \\$","",attprice)
  }
  else{
    attprice<-NA
  }
  #Next steps, extract a title price IF it is present
  title<-txt[1]
  tprice<-gsub("\\$","",str_extract(title,"\\$[0-9,.]+"))
  
  return(c(tprice,attprice))
}

read_post<-function(file){
  txt<-readLines(file)
  price<-parse_price(txt)
  dep<-parse_deposit(txt)
  pets<-parse_pets(txt)
  return(pets)
}

#Let's test this on sac files
sac_price<-sapply(sac_files,read_post)

table(is.na(sac_price)) #Let's see how many did NOT have a att. price
#sixty. okay, which ones?
which(is.na(sac_price))

readLines(sac_files[5704]) #In this case, it's a literal NA here.
#We can't do anything about this!

#5. Extract the deposit amount from the text of each Craigslist post. 
#Is there a relationshipbetween rental price and deposit amount?

parse_deposit<-function(txt){
  #Let's make a two layered strategy:
  #Start by returning lines that contain the phrase 'deposit'
  deposit<-NA
  depgrep<-grep("deposit",tolower(txt))
  if(length(depgrep)>0){
    dep<-txt[depgrep]
    pet<-grepl("pet|dog|cat",tolower(dep))
    dep_nonpet<-dep[pet==FALSE]
    if(length(dep_nonpet)==0){
      deposit<-str_extract(dep_nonpet,"\\$[0-9,.]+")
      if(any(!is.na(deposit))){
        deposit_w_vals<-which(!is.na(deposit))
        deposit<-gsub("\\$","",deposit[max(deposit_w_vals)])
      }
    }
  }
  return(deposit)
}

sac_dep<-sapply(sac_files,read_post)

#6. Extract a categorical feature from each Craigslist post (any part) that measures whetherthe apartment allows pets: cats, dogs, both, or none

pet_str<-"(pet|dog|cat|bird|fish)[es]{0,1} "
pet_positive<-"(allowed|friendly|permit|deposit|family|monthly|rent)"
pet_nego<-"(breed|max|lbs|under)"
pet_none<-"(no|not) "

parse_pets<-function(txt){
  pets<-NA
  pet_text<-grep(pet_str,tolower(txt))
  if(length(pet_text)>0){
    pets<-tolower(paste0(txt[pet_text],collapse=" "))
    pet_reg<-str_extract_all(pets,paste0("[^ ]*[ ]{0,1}[^ ]*[ ]{0,1}",pet_str,"[^ ]*[ ]{0,1}[^ ]*"))
    pos_check<-any(grepl(pet_positive,pet_reg))
    nego_check<-any(grepl(pet_nego,pet_reg))
    none_check<-any(grepl(pet_none,pet_reg))
    if(pos_check==TRUE & nego_check==FALSE & none_check==FALSE){
      return("positive")
    }
    else if(nego_check==TRUE & none_check==FALSE){
      return("negotiable")
    }
    else{
      return("none")
    }
  }
  else{
    return("")
  }
}

sac_pets<-sapply(sac_files,read_post)
