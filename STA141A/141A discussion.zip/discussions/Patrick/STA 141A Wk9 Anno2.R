#STA 141A, Week 9, 6:10-7 PM

library(stringr) #Your best friend, your text savior

#Let's look at the sac data

sac_files<-list.files()

#Q4: Parse the price information. Get the 'attribute price' and the 'title price'

#So we can agree that:
#1. The last price we see will be the attribute price
#2. The first price we see will be the title price

#Basically, we need to extract a function that gets BOTH of these
#and returns them
#It should only get ONE attribute price and ONE title price

parse_price<-function(txt){
  #INPUT: A text file (can be a character vector)
  #OUTPUT: An attribut price and a title price
  #i. Get the attribute price
  price<-c(att=NA,title=NA)
  attprice<-str_extract(txt,"Price: \\$[0-9,.]+")
  attprice<-attprice[!is.na(attprice)] #If it's not NA, keep it.
  #We need to consider a couple of use cases
  #1. The reported attribute price is NA (check)
  #2. There are multiple instances of "Price: $$$"
  if(length(attprice)>0){
    attprice<-attprice[length(attprice)]
    #We need to turn it from "Price $1337" to "1337"
    price[1]<-gsub("Price: \\$","",attprice)
  }
  #ii. Get the title price
  title<-txt[1]
  tprice<-str_extract(title,"\\$[0-9,.]+")
  if(!is.na(tprice)){
    price[2]<-gsub("\\$","",tprice)
  }
  return(as.numeric(price))
}

sacprice<-t(sapply(sac_files,function(x)parse_price(readLines(x))))
rownames(sacprice)<-NULL

#Do the attribute prices line up with the title prices? It seems that they are all the same
#We may need to do further investigation

#Q6: Extract the pet information

#We are going to try to get the pet information

#Four main categories: Both, dogs, cats, negotiable, none

pet_regex<-"(pet|dog|cat|fish|horse|iguana)[es]{0,2} "

both_pets<-"friendly|max|weight|breed|deposit"

parse_pets<-function(txt){
  #INPUT: Some text
  #OUTPUT: Pet status
  #Start by writing a basic version that tries to check if pet policy is mentioned in the file
  pets<-grepl(pet_regex,tolower(txt))
  if(any(pets)){
    pet_snippet<-str_extract(tolower(txt[pets==TRUE]),paste0("\\..*?",pet_regex,".*?\\."))
    is_both<-grepl(both_pets,tolower(pet_snippet))
    if(any(is_both)){
      return("both")
    }
    #Start with this:
    #What's being mentioned? Pets, dogs, or cats?
    is_pets<-any(grepl("pet[s]* ",tolower(pet_snippet)))
    is_dogs<-any(grepl("dog ",tolower(pet_snippet)))
    is_cats<-any(grepl("cat ",tolower(pet_snippet)))
    #Start looking at each condition
    if(is_pets){
      nopets<-any(grepl("(no pets|pets not allowed|pets not permitted)",pet_snippet))
      if(nopets==TRUE){
        return("none")
      }
      else{
        return("both")
      }
    }
    if(is_dogs & is_pets==FALSE){
      nodogs<-any(grepl("(no dogs|dogs not allowed|dogs not permitted)",pet_snippet))
      if(nodogs==TRUE){
        return("none")
      }
      else{
        return("dogs")
      }
    if(is_cats & is_pets==FALSE){
      nocats<-any(grepl("(no cats|cats not allowed|cats not permitted)",pet_snippet))
      if(nocats==TRUE){
        return("none")
      }
      else{
        return("cats")
      }
    }
    }
  }
  else{
    return("")
  }
}

sacpets<-sapply(sac_files,function(x)parse_pets(readLines(x)))

#Food for thought approach:
#Some apartment listings do not separate their posts very well, and the entire post is just one line.
#If you find a listing that has pet info mentioned in only one sentence AND you get that
#You can use much more specific patterns for extracting pet info
#If you get the entire listing, however, it can be very tough to get out
#If you find a way to categorize the posts by 'large' and 'small'
#You could develop separate strategies for extracting pet info from these posts


#GENERAL STRATEGY FOR PETS PROBLEM
#1. Filter out to only have sentences where pets are mentioned
#2. Find specific phrases that reference pet policy
#3. Use the combinations of these phrases to make decisions on pet status