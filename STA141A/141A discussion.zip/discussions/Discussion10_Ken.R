#
# Discussion 10
#
# Ken Wang

# K-Nearest neighbor
# Cross validation

# Toy example 1 (Continuous Y)
# We want to predict someone's weight based on their height. We have height and weight for 10 people. 

height <- c(63.5, 73.3, 68.8, 65, 69, 64.5, 66, 66.3, 68, 64.7)
weight <- c(118, 143, 172, 147, 146, 138, 175, 134, 171, 119)

# If we are given someone's height is 67 inches, then let's predict its weight.

# Step 1: Define and calculate the distance
# In this simple example, we use the Euclidean distance D_i = |X_i - X_i*|

Di <- abs(height - 67)

# Step 2: Specify the number of neighbors
# For example k = 2
k = 2

# Step 3: Find the k neighbors. In other words, the index of the smallest two distances in Di.

# k smallest distances
min.dist <- sort(Di)[1:k]
# Index for the k neighbors
neighbors <- unlist(sapply( min.dist, function(ind){
  nb <- which(Di == ind)
  if ( length(nb) > 1 ) {
    return (sample(nb, 1))
  }else{
    return (nb)
  }
  }))

# Step 4: Find the prediction by averaging

mean(weight[neighbors])

# Organize the above into a function

knn1 <- function(predictor, x, y, k){
  Di <- abs(x - predictor)
  min.dist <- sort(Di)[1:k]
  neighbors <- unlist(sapply( min.dist, function(ind){
    nb <- which(Di == ind)
    if ( length(nb) > 1 ) {
      return (sample(nb, 1))
    }else{
      return (nb)
    }
  }))
  mean(y[neighbors])
}

#----------------------------------------
# Pick a k by cross validiation
#----------------------------------------

# Calculate the distance matirx before cross validation

# Distance matrix
d.mat <- as.matrix(dist(height))
# Sorted distances
d.mat.sorted <- apply(d.mat, 2, sort)

# Leave 1 out
length(weight)
length(height)

cv.error <- sapply(1:10, function(k.ind){
  # outer loop for k
  
  mean( sapply(1:10, function(leave.ind){
    # inner loop is for cross validation 
    # shortest k distances
    min.dist <- unique(d.mat.sorted[-1,leave.ind][1:k.ind])
    # k nearnest neighbor indexes
    neighbors <- unlist(sapply(min.dist, function(ind){
      nb <- which(d.mat[-leave.ind,leave.ind]==ind)
      if ( length(nb)>1) {
        return (sample(nb, 1))
      }else{
        return (nb)
      }
      }))
    # prediction
    abs(mean(weight[-leave.ind][neighbors]) - weight[leave.ind])
  })
  )
  
})

plot(cv.error)

k = which( cv.error == min(cv.error) )

knn1(67, height, weight, 3)


# Toy example 2: (Discrete Y)
# We want to predict someone's gender based on weight and height
# 1 is male
# 0 is female

gender <- c(1, 0, 1, 1, 0, 1, 0, 1, 1, 0)

# Weight and height are given in example 1 above.
bwh <- cbind(weight, height)

data <- cbind(gender, bwh)
data[order(data[,3]),]

# Predict someone is male or female given its weight is 171 and height is 66.

knn2 <- function(predictor, x, y, k){
  # Distance
  Di <- apply(x, 1, function(b.ind){
    sqrt(sum((b.ind-predictor)^2))
  })
  
  # Nearest neighbors
  min.dist <- sort(Di)[1:k]
  neighbors <-  unlist(sapply( min.dist, function(ind){
    nb <- which(Di == ind)
    if ( length(nb) > 1 ) {
      return (sample(nb, 1))
    }else{
      return (nb)
    }
  }))
  
  # Prediction
  votes <- table(gender[neighbors])
  c(0,1)[which(votes == max(votes))[1]]
}

knn2(c(171, 66), bwh, gender, 3)

# Use cross validation as in example 1 to find a k.