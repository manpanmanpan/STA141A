# Discussion 6
#
# Ken Wang
#
# Using regular expression to extract laundry status
# 
# Remember to checkout the stringr cheatsheets.
# Make sure that you go over lecture notes 11/13 to learn regular expression
# Also read R4DS chapter 14


library(stringr)

# Use the first file in messy data for assignment 5 as an example.

post <- readLines('...path.../_ant_apa_d_1-bd-1-bd-water-paid-utility_6718641721.txt')

head(post)

# Look for laundry description
text = sapply( post, function(ind){
  str_subset(tolower(ind), "wd|(^| )washer|dryer|laundry")
  })            #/|\
                # |----- Change everything to lower case

about.laundry <- unlist(text)

# If about.laundry is an empty string, then there is no laundry option in post.
if(length(about.laundry) == 0){
  print("None")
}


wd = c("washer", "dryer", "washer dryer", "washer and dryer")

# Check if there is laundry hook up in unit.
if (str_detect(about.laundry, "hook ?up|(washer|dryer) connection")){
  print("hookup")
}

# Check if there is laundry in unit
if( any(wd %in% about.laundry) ||
           str_detect(about.laundry, c(
             "in( the| every| each)? (unit|apartment|house|home)"
             , "(your own|new|(has|includes)( a)?) (washer|dryer)"
             , "(washer|dryer)( is)? (included|built ?in)"
             , "built ?in laundry"
           ))){
             print('in-unit')
}

# Check if laundry is shared
if (any(str_detect(about.laundry, c(
  "(shared|community|on ?site) (laundry|washer|dryer)"
  , "laundry (room|center|facilit|service|on ?site|in( the)? building)"
  , "(washer|dr[yi]er) on ?site"
  , "coin"
)))){
  print("shared")
}

# Check if laundry is paid
if (str_detect(about.laundry, "fee")){
  print("paid")
}

if (str_detect(about.laundry, "laundromat")){
  print('None')
}

# You may want to organize the above if statements into a function so that you can use it to loop over all the posts looking for laundry status. Other posting features can aslo be extracted similarly with suitable key words.
