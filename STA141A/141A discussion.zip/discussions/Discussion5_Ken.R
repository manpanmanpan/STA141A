#
# Discussion 5
#
# Ken Wang
#
# More examples about Merge
# ggmap
#

## Merge

# A date frame of authors
authors <- data.frame(
  ## I(*) : use character columns of names to get sensible sort order
  surname = I(c("Mr. Tukey", "Mr. Venables", "Mr. Tierney", "Ms. Ripley", "Ms. McNeil")),
  nationality = c("US", "Australia", "US", "UK", "Australia"),
  deceased = c("yes", rep("no", 4)))

# Change surname to name
authorN <- within(authors, { name <- surname; rm(surname) })

# A data frame of names
books <- data.frame(
  name = I(c("Tukey", "Venables", "Tierney",
             "Ripley", "Ripley", "McNeil", "R Core")),
  title = c("Exploratory Data Analysis",
            "Modern Applied Statistics ...",
            "LISP-STAT",
            "Spatial Statistics", "Stochastic Simulation",
            "Interactive Data Analysis",
            "An Introduction to R"),
  other.author = c(NA, "Ripley", NA, NA, NA, NA,
                   "Venables & Smith"))

# Example that fails
merge(authors, books)

# Change the names so that they match exactly

# Use the stringr package
library(stringr)

# Example
str_remove_all("hello there", " there")

# Remove the parentheses
str_remove_all("(hell there)", "[\\(,\\)]")

name <- lapply(authors$surname, function(ind){
  str_remove_all(str_remove_all(ind, "Mr. "), "Ms.")
})

# Unlist 
name <- unlist(name)

# Add the new column to authors
new.authors <- cbind(authors, name)
merge(new.authors, books)

# Update the surname column of authors
authors$surname = name
authors

merge(authors, books, by.x = "surname", by.y = "name", all = T)

# Match
?match
match(1:10, 7:20)


## ggmaps

# Make sure to install the ggmap from github with devtools
install.packages("devtools")
devtools::install_github("dkahle/ggmap", ref = "tidyup")
