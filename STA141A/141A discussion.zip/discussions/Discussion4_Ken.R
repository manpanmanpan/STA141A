# Discussion 4
# 
# Ken Wang
#
#--------------------------------------
# Graphical design
#--------------------------------------

dogs = readRDS("~/OneDrive - UC Davis/School/Classes/Sta 141a/Data/dogs_full.rds")

library(ggplot2)

## Make sure labels don't heavily overlap

# Bad plot
overlap_labels <- ggplot(dogs, aes(popularity_all, lifetime_cost))

overlap_labels +
  geom_point() +
  geom_text(aes(label = breed))

# Use smaller text size
overlap_labels +
  geom_point() +
  geom_text(aes(label = breed), size = 2)

# Reposition the lables
overlap_labels +
  geom_point() +
  geom_text(aes(label = breed), size = 2, vjust = 2)

# Use ggrepel
library(ggrepel)
overlap_labels +
  geom_point() +
  geom_text_repel(aes(label = breed), size = 2)

# Make x and y labels reader friendly
overlap_labels +
  geom_point() +
  xlab("overall popularity") +
  ylab("lifetime cost") +
  geom_text_repel(aes(label = breed), size = 2)


## Avoid overplotting

# Bad plot
mystery <- readRDS("~/OneDrive - UC Davis/School/Classes/Sta 141a/Data/mystery.rds")

overplot <- ggplot(mystery, aes(x, y))

overplot +
  geom_point(size = 10)

# Use smaller size
overplot +
  geom_point(size = 0.5)

# Use transparency
overplot +
  geom_point(size = 1, alpha = 0.2)

# Add contour lines
overplot +
  geom_point(size = 1, alpha = 0.2) +
  geom_density2d(col = 4)

# Save plot with enough resolution 
ggsave("mystery.png", width = 10, height = 5)

#-----------------------------
# merge
#-----------------------------

# A date frame of authors
authors <- data.frame(
  ## I(*) : use character columns of names to get sensible sort order
  surname = I(c("Tukey", "Venables", "Tierney", "Ripley", "McNeil")),
  nationality = c("US", "Australia", "US", "UK", "Australia"),
  deceased = c("yes", rep("no", 4)))

# Change surname to name
authorN <- within(authors, { name <- surname; rm(surname) })

# A data frame of names
books <- data.frame(
  name = I(c("Tukey", "Venables", "Tierney",
             "Ripley", "Ripley", "McNeil", "R Core")),
  title = c("Exploratory Data Analysis",
            "Modern Applied Statistics ...",
            "LISP-STAT",
            "Spatial Statistics", "Stochastic Simulation",
            "Interactive Data Analysis",
            "An Introduction to R"),
  other.author = c(NA, "Ripley", NA, NA, NA, NA,
                   "Venables & Smith"))


# Merge authors with names and books
(m0 <- merge(authorN, books))

# Merge authors with surnames and books
# by.x by.y tells R which columns with different names are common
(m1 <- merge(authors, books, by.x = "surname", by.y = "name"))

## "R core" is missing from authors and appears only here :
merge(authors, books, by.x = "surname", by.y = "name", all = TRUE)
