# 
# Discussin 2
# 
# Ken Wang
#
# Install ggplot2
# Loading and inspecting data sets
# Examples of ggplot2, 
#Reference: ggplot2: Elegant Graphics for Data Analysis by Wickham. The official reference for ggplot2.

# Load the ggplot2 package
library(ggplot2)

data(mpg)

# Examine the first few rows
head(mpg)

# Summarize the mpg
summary(mpg)

# Open the data set in a window
View(mpg)

# Make a plot with ggplot

# Scatter Plot of engien size and high way feul economy
ggplot(mpg, aes(x = displ, y = hwy)) + 
  geom_point()

# Add some color based on class
ggplot(mpg, aes(x = displ, y = cty, colour = class)) +
  geom_point()

# Add fixed color
ggplot(mpg, aes(displ, hwy)) + 
  geom_point(aes(colour = 'blue'))

ggplot(mpg, aes(displ, hwy)) +
  geom_point(colour = 'blue')

# Using faceting for each category
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  facet_wrap(~class)

# Add a smoother to a plot
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  geom_smooth()

# Add a smoother without the confidence interval
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  geom_smooth(se = F)


# Control the smoothness of the line
ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  geom_smooth(se = F, span = 0.2)

ggplot(mpg, aes(displ, hwy)) +
  geom_point() +
  geom_smooth(se = F, span = 1)

# There are different methods than "loess", for example "gam", "lm", "rlm"

# Boxplots and jittered points
# Hwy mpg based on drive type
ggplot(mpg, aes(drv, hwy)) + 
  geom_point()

# Boxplots
ggplot(mpg, aes(drv, hwy)) +
  geom_boxplot()

# Jittered points
ggplot(mpg, aes(drv, hwy)) +
  geom_jitter()

# Violin plot
ggplot(mpg, aes(drv, hwy)) +
  geom_violin()


# Histograms and Frequency Polygons
ggplot(mpg, aes(hwy)) +
  geom_histogram()

ggplot(mpg, aes(hwy)) +
  geom_freqpoly()

# Try with different binwidth
ggplot(mpg, aes(hwy)) +
  geom_freqpoly(binwidth = 2.5)

ggplot(mpg, aes(hwy)) +
  geom_freqpoly(binwidth = 1)

# Compare the distributions of different subgroups
ggplot(mpg, aes(displ, colour = drv)) +
  geom_freqpoly(binwidth = 0.5)

ggplot(mpg, aes(displ, colour = drv)) +
  geom_histogram(binwidth = 0.5) +
  facet_wrap(~drv, ncol = 1)

# Bar charts
ggplot(mpg, aes(manufacturer)) +
  geom_bar()

# Modifying the axes
ggplot(mpg, aes(cty, hwy)) +
  geom_point(alpha =1/3)

# Label x and y axes
ggplot(mpg, aes(cty, hwy)) +
  geom_point(alpha = 1/3) +
  xlab("city driving (mpg)") +
  ylab("highway driving (mpg)")

# Remove the x and y axes
ggplot(mpg, aes(cty, hwy)) +
  geom_point(alpha = 1/3) +
  xlab(NULL) +
  ylab(NULL)

# Change the limit on the x and y axes
ggplot(mpg, aes(drv, hwy)) +
  geom_jitter(width = 0.25)

ggplot(mpg, aes(drv, hwy)) +
  geom_jitter(width = 0.25) +
  xlim("f", "r") +
  ylim(20, 30)

# To set only one limit with NA
ggplot(mpg, aes(drv, hwy)) +
  geom_jitter(width = 0.25) +
  ylim(NA, 30)


# Save the plot
p <- ggplot(mpg, aes(displ, hwy, colour = factor(cyl))) +
  geom_point()

print(p)

ggsave("plot.png", width = 5, height = 5)
