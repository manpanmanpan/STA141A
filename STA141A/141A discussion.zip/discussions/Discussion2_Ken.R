# 
# Discussion 3
# 
# Ken Wang
# 
# 1. Taking subsets
# 2. sapply(), aggregate(), and tapply()

# Modify legend with ggplot
library(ggplot2)
data(mpg)

# Make a scate plot colored based on class
p <- ggplot(mpg, aes(x = displ, y = cty, colour = class)) +
  geom_point()

# Change legend text and title
p + scale_color_manual(labels = c('a','b','c','d','e','f','g'), values = seq(1,7)) +
  guides(color = guide_legend(title = "Vechicle Class"))

# Get the dog data

dogs <- readRDS("/Users/ken/OneDrive\ -\ UC\ Davis/School/Classes/Sta\ 141a/Data/dogs_full.rds")

head(dogs)

# Subset the breed variable

breed <- dogs$breed

breed <- dogs[,1]

# Get the 10th observation in the variable breed
dogs[[1]][[10]]

dogs[[10,1]]

dogs[10,1]

typeof(dogs[[1]][[10]])
typeof(dogs[[10,1]])
typeof(dogs[10,1])

# subset function
popular_dogs <- subset(dogs, popularity > 60, select = c(breed, group, popularity))

# sapply for repeated operation

# See if popularity is over 80 for the popular dogs
sapply(popular_dogs$popularity, function(ind){ind > 80})

# aggregate and tapply for grouping
# When to use aggregate or tapply?
# 1. A dataset can be broken up into groups
# 2. Want to apply a function to each group (for example mean)

# calculate mean popularity based on group
aggregate(dogs$popularity, by = list(dogs$group), mean, na.rm = T)

# or use tapply
tapply(dogs$popularity, dogs$group, mean, na.rm = T)
