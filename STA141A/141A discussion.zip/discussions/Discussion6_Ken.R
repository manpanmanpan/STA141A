#
# Discussion 6
# 
# Ken Wang
#
# Loading text from files with readLines()
# Breaking down problems into small steps
# Writing functions to do small steps
# A little about stringr package and re.


## Use readLines to read txt files

# Read the STA.txt file in catalog

sta = readLines("/Users/ken/OneDrive\ -\ UC\ Davis/School/Classes/Sta\ 141a/Data/catalog/STA.txt")

head(sta)
length(sta)
sta[1]
sta[2]

# Remove the empty strings
sta <- grep("STA", sta, value = T)
length(sta)
head(sta)
sta[1]
sta[2]

library(stringr)
# Get all course numbers
course.num <- str_match(sta, "STA [0-9]{3}")

# Make sure that the letters are included
course.num <- str_match(sta, "STA [0-9]{3}[A-Z]?")
head(course.num)
course.num <- as.data.frame(course.num)
names(course.num) = "Course Number"
head(course.num)

# Get all course titles
course.title <- str_match( sta, "(?<=[0-9]{3}[A-Z]?)(.*?)(?=\\()")[,1]

head(course.title)

# Remove "-" before course titles
course.title <- str_remove_all(course.title, "[A-Z]?—")
course.title <- as.data.frame(course.title)
names(course.title) <- "Course Title"
head(course.title)

# Create a data frame with course number and course title

sta.data <- cbind(course.num, course.title)
head(sta.data)

# Functions
# put the above steps into a function so that we can use it for any files in the catalog folder



Course.number <- function(file.path, course){
  # This function reads the file from the file.path
  # and finds course numbers contained in that file.
  
  # read file from path
  txt <- readLines(file.path)
  
  # remove empty strings
  txt <- grep(course, txt, value = T)
  
  # get course number
  course.num <- str_match(txt, paste(course, "[0-9]{3}[A-Z]?", sep = ' '))
  
  return( course.num )
}



sta.path <- "/Users/ken/OneDrive\ -\ UC\ Davis/School/Classes/Sta\ 141a/Data/catalog/STA.txt"

Course.number(file.path = sta.path, "STA" )

ead.path <- "/Users/ken/OneDrive\ -\ UC\ Davis/School/Classes/Sta\ 141a/Data/catalog/EAD.txt"

Course.number(file.path = ead.path, "EAD")
