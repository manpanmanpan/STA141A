# STA 141A
# Lecture 17 (Nov 29)

# Admin:
#   * Nick has OH today 4-5pm (max 6pm) in MSB 1117
#   * Assignment 5 due Dec 1
#   * Assignment 6 due Dec 11
#   * Reminder: We will not have an in-class final.

# References for this lecture:
#   * An Introduction to Statistical Learning, Ch 2
#     (get it at https://www-bcf.usc.edu/~gareth/ISL/)
# 
# References for the next two lectures:
#   * An Introduction to Statistical Learning, Ch 5.1
#   * The Art of R Programming, Ch 8, 14

# Today was a blackboard lecture. I covered:
#   * Overview of Statistical Models & Machine Learning
#   * The k-Nearest Neighbors Classification Model
